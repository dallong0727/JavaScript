package com.weather.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;

import com.weather.model.WeatherVO;
import com.weather.service.ContentServiceImpl;
import com.weather.service.FoodServiceImpl;
import com.weather.service.RegistServiceImpl;
import com.weather.service.WeatherService;

@WebServlet("*.Weather")
public class WeatherController extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
    public WeatherController() {
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}

	protected void doAction(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		String uri = request.getRequestURI(); //URI정보
		String path = request.getContextPath(); //컨텍스트 패스 정보
		String command = uri.substring(path.length());
		
		System.out.println(command);
		
		WeatherService service = null;
		
		if(command.equals("/Kakao.Weather")) {		
						
			service = new RegistServiceImpl();
			service.execute(request, response);
			
			service = new FoodServiceImpl();
			service.execute(request, response);	
			
			
								
		}else if(command.equals("/login.Weather")) {			
			service = new ContentServiceImpl();
			service.execute(request, response);	
			
			WeatherVO vo = (WeatherVO)request.getAttribute("vo");
			
			JSONObject jobj = new JSONObject();
			jobj.put("city", vo.getCity());
			jobj.put("weather",vo.getWeather());
			jobj.put("humidity",vo.getHumidity());
			jobj.put("temp_max",vo.getTemp_max());
			jobj.put("temp_min",vo.getTemp_min());
			jobj.put("speed",vo.getSpeed());
			jobj.put("avg_temp",vo.getAvg_temp());
			
			System.out.println(jobj.toJSONString());
			
			response.setCharacterEncoding("utf-8");
			response.setContentType("application/json");
			PrintWriter out = response.getWriter();
			out.println(jobj.toJSONString());
			
		} 
	}
}
