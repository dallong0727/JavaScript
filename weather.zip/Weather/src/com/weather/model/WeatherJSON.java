package com.weather.model;

public class WeatherJSON {
    

}
