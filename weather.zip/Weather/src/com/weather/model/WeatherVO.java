package com.weather.model;

import java.sql.Timestamp;

public class WeatherVO {
	
	private int wno;
	private String city;
	private String weather;
	private String humidity;
	private String temp_max;
	private String temp_min;
	private String avg_temp;
	private String speed;
	private Timestamp regdate;
	
	public WeatherVO() {
		// TODO Auto-generated constructor stub
	}
	 
	public WeatherVO(String city, String weather, String humidity, String temp_max, String temp_min, String speed, String avg_temp) {
		super();
		this.city = city;
		this.weather = weather;
		this.humidity = humidity;
		this.temp_max = temp_max;
		this.temp_min = temp_min;
		this.speed = speed;
		this.avg_temp=avg_temp;
	}

	public WeatherVO(int wno, String city, String weather, String humidity, String temp_max, String temp_min,
			 String speed, String avg_temp, Timestamp regdate) {
		super();
		this.wno = wno;
		this.city = city;
		this.weather = weather;
		this.humidity = humidity;
		this.temp_max = temp_max;
		this.temp_min = temp_min;
		this.avg_temp = avg_temp;
		this.speed = speed;
		this.regdate = regdate;
	}

	public int getWno() {
		return wno;
	}

	public void setWno(int wno) {
		this.wno = wno;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getWeather() {
		return weather;
	}

	public void setWeather(String weather) {
		this.weather = weather;
	}

	public String getHumidity() {
		return humidity;
	}

	public void setHumidity(String humidity) {
		this.humidity = humidity;
	}

	public String getTemp_max() {
		return temp_max;
	}

	public void setTemp_max(String temp_max) {
		this.temp_max = temp_max;
	}

	public String getTemp_min() {
		return temp_min;
	}

	public void setTemp_min(String temp_min) {
		this.temp_min = temp_min;
	}

	public String getAvg_temp() {
		return avg_temp;
	}

	public void setAvg_temp(String avg_temp) {
		this.avg_temp = avg_temp;
	}

	public String getSpeed() {
		return speed;
	}

	public void setSpeed(String speed) {
		this.speed = speed;
	}

	public Timestamp getRegdate() {
		return regdate;
	}

	public void setRegdate(Timestamp regdate) {
		this.regdate = regdate;
	}

	
}
