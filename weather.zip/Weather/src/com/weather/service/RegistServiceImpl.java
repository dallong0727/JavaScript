package com.weather.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.weather.model.WeatherDAO;
import com.weather.model.WeatherVO;

public class RegistServiceImpl implements WeatherService{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		String city = request.getParameter("city");
		String weather = request.getParameter("weather");
		String humidity = request.getParameter("humidity");
		String temp_max = request.getParameter("temp_max");
		String temp_min = request.getParameter("temp_min");
		String avg_temp = String.valueOf((Integer.parseInt(temp_max)+Integer.parseInt(temp_min))/2);
		String speed = request.getParameter("speed");
		WeatherDAO dao = WeatherDAO.getInstance();
		WeatherVO vo = new WeatherVO(city, weather, humidity, temp_max, temp_min, speed,avg_temp);
		dao.regist(vo);
		
		request.setAttribute("vo", vo);	
		
		HttpSession session = request.getSession();		
		session.setAttribute("city", city);
	}
	
	
}
